# Clemson AMP poster package

Extract this archive and open amp-plots/clemson_amp/README.md, FIGURE_GUIDE.md,
and VALIDATION.md. Figures are supplied as PNG and PDF.

This package includes inputs, processed meteorology, terrain receptor/source
elevations, model results, quality/provenance reports, and original input samples.
Raw NOAA archives and the 42MB terrain archive/52MB raster remain downloaded in
the cloud environment and are excluded from this compact export. The included
fetch scripts retrieve those exact public sources and verify cached checksums.

EPA model executables are not bundled. To recompute on another machine, use the
matching official versions and supply their paths as documented in README.md.
AERPLOT26135 requires Windows; its prepared inputs and the actual AERMOD plot
files are included. AERPLOT itself was not executed in the Linux cloud machine.

The figures represent a hypothetical source normalized to1g/s; they are not
measured AMP emissions or concentrations. Read the stated weather/sensor and
surface-parameter assumptions before using them on a poster.

Execution provenance records the original cloud paths. Recomputing/plotting on
another machine requires new local execution records and executable paths;
stale-result verification deliberately rejects relabeled results.
